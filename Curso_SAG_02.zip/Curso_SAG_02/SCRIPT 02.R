# Instalação e Carregamento dos Pacotes Necessários para a Aula -----------

pacotes <- c("rgdal","raster","tmap","maptools","tidyverse","broom","knitr",
             "kableExtra","RColorBrewer","ggplot2","devtools", "dplyr", "ggplot2", "ggtext","ggspatial", "ggthemes", "rgdal", "sf", "sp","tidyr","tidyverse","sf","tmap","rgdal","rgeos","adehabitatHR","knitr",
             "kableExtra")

if(sum(as.numeric(!pacotes %in% installed.packages())) != 0){
  instalador <- pacotes[!pacotes %in% installed.packages()]
  for(i in 1:length(instalador)) {
    install.packages(instalador, dependencies = T)
    break()}
  sapply(pacotes, require, character = T) 
} else {
  sapply(pacotes, require, character = T) 
}


################################## SHAPEFILES ##################################

# 1. PARTE INTRODUTÓRIA

# Carregando um shapefile -------------------------------------------------
shp_sp <- readOGR(dsn = "shapefile_sp", layer = "estado_sp")

# Características básicas do objeto shp_sp
summary(shp_sp)

# Classe e tipo do objeto carregado
class(shp_sp)

# Acessando a base de dados e outros componentes do objeto shp_sp ---------
shp_sp

# Para acessar as variáveis da base de dados atrelada ao shapefile, utilizaremos
# o operador $:
shp_sp$NM_MUNICIP
shp_sp$CD_GEOCMU

# Para acessar os outros componentes do shapefile, utilizaremos o operador @:
shp_sp@polygons #Posições geográficas dos polígonos
shp_sp@plotOrder #Ordem de plotagem dos polígonos
shp_sp@bbox #Eixo X (Longitude Oeste e Leste; Latitude Norte e Sul)
shp_sp@proj4string@projargs #Sistema de projeção geográfica do shapefile


# Plotagem básica de um shapefile -----------------------------------------
plot(shp_sp)


# Introdução à manipulação de dados em shapefiles -------------------------

#  caso haja a necessidade da inserção de dados externos? ---------------

# Carregando uma base de dados real a respeito dos municípios de SP:
load("dados_sp.RData")

# Observando a base de dados carregada
dados_sp %>% 
  kable() %>%
  kable_styling(bootstrap_options = "striped", 
                full_width = TRUE, 
                font_size = 12)

# Para combinar os dados do objeto dados_sp com a base de dados de nosso 
# shapefile, podemos utilizar a função merge():
shp_dados_sp <- merge(x = shp_sp,
                      y = dados_sp,
                      by.x = "CD_GEOCMU",
                      by.y = "codigo")



# Salvando nosso shapefile:
writeOGR(obj = shp_dados_sp, 
         layer = "nosso_novo_shapefile", 
         driver = "ESRI Shapefile", 
         dsn = "shp_novo")

# Caso a intenção fosse a plotagem dos dados do dataset presente no objeto 
# shp_dados_sp, a lógica seria a mesma já aprendida no curso:
shp_dados_sp@data %>% 
  ggplot() +
  geom_histogram(aes(x = idh),
                 fill = "deepskyblue4",
                 color = "white") +
  labs(x = "IDH",
       y = "Frequência") +
  theme_bw()

# Porém, como deveria ser feita a plotagem espacial dos dados do dataset do 
# objeto shp_dados_sp?

# A seguir, a solução via ggplot2; depois, a solução via pacote tmap, que será
# adotado pelo curso


# 2. VISUALIZAÇÃO DE DADOS ESPACIAIS

# Utilizando a tmap: ------------------------------------------------------
tm_shape(shp = shp_dados_sp) +
  tm_fill(col = "idh", palette = "Blues")


# Como saber quais paletas de cores podem ser utilizadas? -----------------
display.brewer.all()

# Vamos reconstruir o último mapa, utilizando uma nova paleta de cor e propondo
# 4 variações de cores:
tm_shape(shp = shp_dados_sp) + 
  tm_fill(col = "idh", 
          style = "quantile", 
          n = 4, 
          palette = "Greens")

# Adicionando um histograma ao mapa anterior
tm_shape(shp = shp_dados_sp) + 
  tm_fill(col = "idh", 
          style = "quantile", 
          n = 4, 
          palette = "Greens", 
          legend.hist = TRUE)

# Reposicionando o histograma
tm_shape(shp = shp_dados_sp) + 
  tm_fill(col = "idh", 
          style = "quantile", 
          n = 4, 
          palette = "Greens", 
          legend.hist = TRUE) +
  tm_layout(legend.outside = TRUE)

# Posicionando manualmente o histograma, e adicionando um título
tm_shape(shp = shp_dados_sp) + 
  tm_fill(col = "idh", 
          style = "quantile", 
          n = 4, 
          palette = "BuPu", 
          legend.hist = TRUE) +
  tm_layout(legend.text.size = 0.7,
            legend.title.size = 0.9,
            legend.hist.size = 0.5,
            legend.hist.height = 0.2,
            legend.hist.width = 0.3,
            frame = FALSE,
            main.title = "A Distribuição do IDH nos Municípios de SP")

# Adicionando uma bússola e bordas aos polígonos
tm_shape(shp = shp_dados_sp) + 
  tm_fill(col = "idh", 
          style = "quantile", 
          n = 4, 
          palette = "Reds", 
          legend.hist = TRUE) +
  tm_layout(legend.text.size = 0.7,
            legend.title.size = 0.9,
            legend.hist.size = 0.5,
            legend.hist.height = 0.2,
            legend.hist.width = 0.3,
            frame = F,
            main.title = "A Distribuição do IDH nos Municípios de SP") +
  tm_borders(alpha = 0.8) +
  tm_compass(type = "8star", 
             show.labels = 3)

# Adicionando escala
tm_shape(shp = shp_dados_sp) + 
  tm_fill(col = "idh", 
          style = "quantile", 
          n = 4, 
          palette = "Reds", 
          legend.hist = TRUE) +
  tm_layout(legend.text.size = 0.7,
            legend.title.size = 0.9,
            legend.hist.size = 0.5,
            legend.hist.height = 0.2,
            legend.hist.width = 0.3,
            frame = F,
            main.title = "A Distribuição do IDH nos Municípios de SP") +
  tm_borders(alpha = 0.8) +
  tm_compass(type = "8star", 
             show.labels = 3)+
tm_scale_bar()

# 3. DESMEMBRANDO SHAPEFILES

# Carregando um novo shapefile:
shp_mundo <- readOGR(dsn = "shapefile_mundo", layer = "mundo")

# Visualizando o shapefile shp_mundo:
tm_shape(shp = shp_mundo) + 
  tm_borders()

# Observando as variáveis da base de dados do objeto shp_mundo:
shp_mundo@data %>% 
  kable() %>%
  kable_styling(bootstrap_options = "striped", 
                full_width = TRUE, 
                font_size = 12)

# Suponha que a intenção seja a de criar um shapefile da América do Sul. Assim,
# note que a variável contnnt consegue estratificar os países desejados.

# Dessa forma:
shp_amsul <- shp_mundo[shp_mundo@data$contnnt == "South America", ]

# Plotando o  objeto shp_amsul:
tm_shape(shp = shp_amsul) + 
  tm_borders()


# 4. COMBINANDO SHAPEFILES

# Vamos supor que a intenção seja a de construir um shapefile do Mercosul.

# Carregando shapefiles a serem combinados
shp_argentina <- readOGR(dsn = "shapefile_mercosul", layer = "argentina_shapefile")
shp_brasil <- readOGR(dsn = "shapefile_mercosul", layer = "brasil_shapefile")
shp_paraguai <- readOGR(dsn = "shapefile_mercosul", layer = "paraguai_shapefile")
shp_venezuela <- readOGR(dsn = "shapefile_mercosul", layer = "venezuela_shapefile")

# A combinação pode ser feita com a função bind(), do pacote raster
shp_mercosul <- bind(shp_argentina, 
                     shp_brasil, 
                     shp_paraguai, 
                     shp_venezuela)

# Observando a base de dados do objeto shp_mercosul:
shp_mercosul@data %>% 
  kable() %>%
  kable_styling(bootstrap_options = "striped", 
                full_width = TRUE, 
                font_size = 12)

# Visualizando o shapefile criado shp_mercosul:
tm_shape(shp = shp_mercosul) + 
  tm_borders(lwd = 1) +
  tm_fill(col = "mercosul") +
  tm_layout(legend.width = 0.8)


# FIM PARTE 1
# Instalação e Carregamento dos Pacotes Necessários para a Aula -----------

# 1. CRIANDO UM OBJETO SF A PARTIR DE UMA BASE DE DADOS

# Carregando a base de dados
load("shoppings.RData")

# Observando a classe do objeto shoppings:
class(shoppings)

# Observando as variáveis da base de dados shoppings:
shoppings %>% 
  kable() %>%
  kable_styling(bootstrap_options = "striped", 
                full_width = TRUE, 
                font_size = 12)

# Criando um objeto do tipo sf a partir de um data frame:
sf_shoppings <- st_as_sf(x = shoppings, 
                         coords = c("longitude", "latitude"), 
                         crs = 4326)

# Observando a classe do objeto sf_shoppings:
class(sf_shoppings)

# Um componente interessante do objeto sf_shoppings é chamado geometry:
sf_shoppings$geometry

# Note que um objeto sf é, de fato, um data frame georreferenciado. Não há
# polígonos atrelados a ele, nem a necessidade de se utilizar o operador @!

# Plotando o objeto sf_shoppings de forma espacial:
tm_shape(shp = sf_shoppings) + 
  tm_dots(size = 1)

# Adicionando uma camada de um mapa do Leafleet que considere a bounding box do 
# objeto sf_shoppings:
tmap_mode("view")
tm_shape(shp = sf_shoppings) + 
  tm_dots(col = "deepskyblue4", 
          border.col = "black", 
          size = 0.2, 
          alpha = 0.8)

tmap_mode("plot")

#tmap_mode("plot") #Para desativar as camadas de mapas on-line


# 2. COMBINANDO UM OBJETO SIMPLE FEATURE COM UM SHAPEFILE

# Carregando um shapefile do município de São Paulo
shp_saopaulo <- readOGR("shapefile_municipio", "municipio_sp")

# Visualização gráfica do objeto shp_saopaulo:
tm_shape(shp = shp_saopaulo) + 
  tm_borders()

# Combinando o objeto shp_saopaulo com o objeto sf_shoppings:
tm_shape(shp = shp_saopaulo) + 
  tm_borders(alpha = 0.5) +
  tm_shape(shp = sf_shoppings) + 
  tm_dots(col = "regiao", 
          size = 0.02)


# 3. BUFFER ANALYSIS

# O buffering é uma técnica para se medir distâncias para fora de um dado ponto
# geográfico.

# A aplicação da técnica de buffering pode ser feita com o uso da função 
# gBuffer(), do pacote rgeos:
buffer_shoppings <- gBuffer(spgeom = sf_shoppings,
                            width = 1500,
                            byid = TRUE)

# A função gBuffer() não funciona com objetos do tipo sf. Para utilizá-la,
# precisaremos converter o objeto sf_shoppings para o tipo spatial points (sp).

# Para tanto, primeiramente, precisaremos isolar as coordenadas de longitude e 
# de latitude do data frame original shoppings:
coordenadas_shoppings <- cbind(shoppings$longitude,
                               shoppings$latitude)

coordenadas_shoppings

# Depois, utilizaremos a função SpatialPoints() para criar um objeto do tipo sp:
sp_shoppings <- SpatialPoints(coords = coordenadas_shoppings,
                              proj4string = CRS("+proj=longlat"))

# Criamos nosso primeiro objeto de classe sp! Vamos explorá-lo:
sp_shoppings@coords
sp_shoppings@bbox
sp_shoppings@proj4string@projargs

# Uma plotagem básica:
plot(sp_shoppings)

# A função SpatialPoints() não permite a existência de um data frame em um
# objeto sp. Mais a frente, estudaremos a função SpatialPointsDataFrame() que
# quebra essa lógica e permite a existência de uma base de dados atrelada a
# um objeto de classe sp.

# Visualizando o resultado:
tmap_mode("plot")

tm_shape(shp = sp_shoppings) + 
  tm_dots(size = 1)

# Vamos tentar aplicar a função gBuffer() mais uma vez:
buffer_shoppings <- gBuffer(spgeom = sp_shoppings,
                            width = 1000,
                            byid = TRUE)

# Dessa vez, o erro foi diferente. Além de exigir um objeto de classe sp,
# a função gBuffer() exige que o objeto se oriente com distâncias euclidianas.
# Nosso atual objeto se orienta de forma geodésica.
shoppings_UTM <- spTransform(x = sp_shoppings,
                             CRSobj = CRS("+init=epsg:22523"))

# Visualizando o resultado:
tm_shape(shp = shoppings_UTM) + 
  tm_dots(size = 1)

# Agora sim, poderemos aplicar a função gBuffer():
buffer_shoppings <- gBuffer(spgeom = shoppings_UTM, 
                            width = 1000, 
                            byid = TRUE)

# Plotagem do objeto buffer_shoppings:
tm_shape(shp = buffer_shoppings) + 
  tm_borders()

tmap_mode("view")

tm_shape(shp = buffer_shoppings) + 
  tm_borders()

# Combinando os objetos shp_saopaulo, sf_shoppings e buffer_shoppings:
tm_shape(shp = shp_saopaulo) + 
  tm_borders(alpha = 0.5) +
  tm_shape(shp = sf_shoppings) + 
  tm_dots(col = "regiao", 
          size = 0.02) +
  tm_shape(buffer_shoppings) + 
  tm_borders(col = "black") 


# 4. BUFFER UNION

# A técnica de buffer union combina aqueles outputs da técnica de buffering que,
# por ventura, se encontrem.
buffer_union <- gUnaryUnion(spgeom = buffer_shoppings)


tm_shape(shp = shp_saopaulo) + 
  tm_borders(alpha = 0.5) +
  tm_shape(shp = sf_shoppings) + 
  tm_dots(col = "regiao", 
          size = 0.02) +
  tm_shape(shp = buffer_union) + 
  tm_borders(col = "black") + 
  tm_fill(col = "gray",
          alpha = 0.5) 


# 5. KERNEL DENSITIES

# A técnica de kernel densities calcula a densidade da presença de pontos de
# interesse em determinada área geográfica.

# O primeiro passo será criar um objeto sp com a base de dados atrelada a ele:
shoppings_sp_df <- SpatialPointsDataFrame(data = shoppings,
                                          coords = coordenadas_shoppings,
                                          proj4string = CRS("+proj=longlat"))


# Note como a função SpatialPointsDataFrame() permite a existência de um data
# frame junto a nosso objeto de classe sp:
shoppings_sp_df@data

# Para o cálculo das kernel densities, podemos utilizar a função kernelUD():
shoppings_dens <- kernelUD(xy = shoppings_sp_df,
                           h = "href",
                           grid = 1000,
                           boundary = NULL)

plot(shoppings_dens)

# Para estabelecer as zonas com maior densidade, propomos o seguinte:
zona1 <- getverticeshr(x = shoppings_dens, percent = 20) 
zona2 <- getverticeshr(x = shoppings_dens, percent = 40) 
zona3 <- getverticeshr(x = shoppings_dens, percent = 60) 
zona4 <- getverticeshr(x = shoppings_dens, percent = 80)

tmap_options(check.and.fix = TRUE) 

tm_shape(shp = shp_saopaulo) + 
  tm_fill(col = "gray90") + 
  tm_borders(col = "white", alpha = 0.5) + 
  tm_shape(shp = shoppings_sp_df) + 
  tm_dots(col = "regiao", size = 0.25) + 
  tm_shape(zona1) + 
  tm_borders(col = "firebrick4", lwd = 2.5) +
  tm_fill(alpha = 0.4, col = "firebrick4") + 
  tm_shape(zona2) + 
  tm_borders(col = "firebrick3", lwd = 2.5) + 
  tm_fill(alpha = 0.3, col = "firebrick3") + 
  tm_shape(zona3) + 
  tm_borders(col = "firebrick2", lwd = 2.5) + 
  tm_fill(alpha = 0.2, col = "firebrick2") +
  tm_shape(zona4) + 
  tm_borders(col = "firebrick1", lwd = 2.5) + 
  tm_fill(alpha = 0.1, col = "firebrick1")


# FIM ---------------------------------------------------------------------

#PARTE 3 ACESSANDO BANCOS DE DADOS VIRTUAIS
#1. GEOBR - PACOTE PARA DADOS ESPACIAIS
#para instalar o pacote ‘geobr’
devtools::install_github("ipeaGIT/geobr", subdir = "r-package")
library(geobr)

#Verificar dados do GEOBR
Info=list_geobr()

#Selecionar dados dos Biomas Brasileiros
biomas <- read_biomes(year = 2019, simplified = TRUE, showProgress = FALSE)
#Características do SHP
head(biomas)
##Plotagem básica das camadas
plot(biomas)

class(biomas)


##Plotando com TMAP
tm_shape(shp = biomas) +
  tm_fill(col = "name_biome", palette = "Set2")+
  tm_layout(legend.text.size = 0.7,
            legend.title.size = 0.9,
            legend.hist.size = 0.5,
            legend.hist.height = 0.2,
            legend.hist.width = 0.3,
            frame = FALSE,
            main.title = "Biomas do Brasil")+
  tm_compass(type = "8star", 
             show.labels = 3)

##Selecionar um municipio -> Alterar code_muni
natal=read_municipality(code_muni = 2408102,year = 2020,simplified = TRUE,showProgress = TRUE)

#Plotagem básica RN
ggplot(natal)+geom_sf()

##Estados brasileiros
estados=read_state(code_state = "all",year = 2010,simplified = TRUE,showProgress = TRUE)
#Plotagem básica RN
ggplot(estados)+geom_sf()

##Vamos alterar as cores dos contornos e do preenchimento -> Checar https://r-charts.com/colors/
ggplot(natal) + 
  geom_sf(color = "grey80",fill="aquamarine1")

##Plotando combinações de Shps
ggplot(biomas)+geom_sf(color = "grey80", aes(fill = biomas$name_biome))+geom_sf(data=estados, fill=NA)


##Exportar mapa
ggsave("biomas.png", width = 8, height = 8, dpi = 300)
##Exportar SHP
st_write(biomas, "biomas.shp")

#2.uSANDO IPEADATAR
#Instalar Pacote
install.packages("ipeadatar")
#Acionar pacote
library(ipeadatar)

#analisar temas dispon?veis
temas=available_subjects(language =  "br")
#Analisar series de dados dispon?veis
series=available_series(language = "br")
#Filtrar s?ries de dados por temas
series_social=subset(series,theme == "Social")
#Buscar dados -> Analfabetismo
EDUC=ipeadata("ADH_T_ANALF15M", language = c("en", "br"), quiet = FALSE)
#Filtrar Dados por estado
EDU_RN=subset(EDUC,tcode >=2400000 & tcode<=2500000)
#Filtrar Dados por Pesquisa
EDURN_2010=subset(EDU_RN,date=="2010-01-01")
#Associar a Mapa

##Extrair malha do RN
RN=read_municipality(code_muni = 24,year = 2010,simplified = TRUE,showProgress = TRUE)
plot(RN)
##Juntando SHPS + informa??es baixadas
shp_educ_rn <- merge(x = RN,
                     y = EDURN_2010,
                     by.x = "code_muni",
                     by.y = "tcode")
#Plotagem BÁsica
tm_shape(shp = shp_educ_rn) +
  tm_fill(col = "value", palette = "Greens")

####PARTE 4 MODELANDO ILHAS DE CALOR----------------------------------------

#Instalar Pacotes
devtools::install_github("ByMaxAnjos/LCZ4r")
library(LCZ4r)

#Baixar dados para um local específico
cwb=lcz_get_map(city = "Curitiba", roi = NULL, isave_map = FALSE, isave_global = FALSE)
pinhais=lcz_get_map(city = "Pinhais", roi = NULL, isave_map = FALSE, isave_global = FALSE)
arauc=lcz_get_map(city = "Araucaria",roi = NULL, isave_map = FALSE, isave_global = FALSE)
col=lcz_get_map(city = "Colombo,Paraná",roi = NULL, isave_map = FALSE, isave_global = FALSE)
sjp=lcz_get_map(city = "São José dos Pinhais,Paraná",roi = NULL, isave_map = FALSE, isave_global = FALSE)
faz=lcz_get_map(city = "Fazenda Rio Grande,Paraná",roi = NULL, isave_map = FALSE, isave_global = FALSE)
alm=lcz_get_map(city = "Almirante Tamandaré,Paraná",roi = NULL, isave_map = FALSE, isave_global = FALSE)

#Juntar as lccz de diversas cidades
resul <- raster::merge(cwb, pinhais,arauc,col,faz,alm,sjp)
#Visualização
plot(resul)
#Plotagem 
lcz_plot_map(resul)
#Área de cada LCZ
lcz_cal_area(resul, iplot = TRUE, isave = FALSE, inclusive = FALSE)
#Parâmetros que formam a LCZ
resul_p <- lcz_get_parameters(resul, istack = TRUE)
summary(resul_p)
#Plotar Skyview Factor
lcz_plot_parameters(resul_p,iselect = "SVF1")
#Plotar Fração Construída média da SUperfície
lcz_plot_parameters(resul_p,iselect = "BSF3")
#Plotar Calor Antropogênico médio
lcz_plot_parameters(resul_p,iselect = "AH3")

#Abrir dados coletados em campo
data=read.csv("dados_cwb_lcz.csv")
#Ajustar coluna de datas
data$date <- as.POSIXct(data$date, format = "%m/%d/%Y %H:%M")
data$date <- as.POSIXct(data$date, format = "%d-%m-%Y %H:%M:%S")
summary(data)

#Gerar uma série temporal
my_ts <- lcz_ts(resul, data, var = "airT",station_id = "station", year = 2015,month=12)
plot(my_ts)

#Interpolagem simples
interp <- lcz_interp_map(resul, data, var = "airT", station_id = "station", tp.res = "day",by="month", sp.res= 100,year = 2015,day=5,hour=16, month=12,LCZinterp= FALSE)
lcz_plot_interp(interp, sp.res = 100, tp.res = "hour",year = 2015, month= 12, day = 5, caption = "LCZ4r, 2024", fill = "Degree Celsius")
#Interpolar com LCZ
interp <- lcz_interp_map(resul, data, var = "airT", station_id = "station", tp.res = "day",by="month", sp.res= 100,year = 2015,day=5,hour=16, month=12,LCZinterp= TRUE)
#Plotar com LCZ
lcz_plot_interp(interp, sp.res = 100, tp.res = "hour",year = 2015, month= 12, day = 5, caption = "LCZ4r, 2024", fill = "Degree Celsius")


